A Pen created at CodePen.io. You can find this one at https://codepen.io/gaffareljeremie/pen/xGXQaV.

 This is a alert box, but in Material Design (Google's new design), with some materials animations